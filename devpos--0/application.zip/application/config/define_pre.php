<?php
define('SERVICE', 'http://provider.ultimatekode.com/geo/107/check.php');
define('APPVER', '?v=6.1');
define('UPDATE_SERVICE', 'http://provider.ultimatekode.com/updates/');// change it to on for exclusive
